#include <iostream>
#include <string>
using namespace std;

struct Student {
    string name;
    int age;
    float total_marks;
};

int main() {
    Student s1, s2;

    
    cout << "Enter details for Student 1:\n";
    cout << "Name: ";
    cin.ignore(); 
    getline(cin, s1.name); 
    cout << "Age: ";
    cin >> s1.age;
    cout << "Total Marks: ";
    cin >> s1.total_marks;

 
    cout << "\nEnter details for Student 2:\n";
    cout << "Name: ";
    cin.ignore();
    getline(cin, s2.name);
    cout << "Age: ";
    cin >> s2.age;
    cout << "Total Marks: ";
    cin >> s2.total_marks;

    float avg_marks = (s1.total_marks + s2.total_marks) / 2.0;

    
    cout << "\n--- Displaying Information ---\n";
    cout << "Student 1 -> Name: " << s1.name << ", Age: " << s1.age << ", Marks: " << s1.total_marks << endl;
    cout << "Student 2 -> Name: " << s2.name << ", Age: " << s2.age << ", Marks: " << s2.total_marks << endl;
    
    cout << "\nAverage of Total Marks: " << avg_marks << endl;

    return 0;
}
