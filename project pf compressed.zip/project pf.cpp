#include <iostream>
#include <string> 

using namespace std;

void printWelcomeMessage();
void printMenu();
float checkGovTax(float salary);
float checkPrivateTax(float salary);

int main() 
{
    
    string names[50];
    int sectors[50];     
    float salaries[50];
    float taxes[50];

    int employeeCount = 0;
    char repeatChoice;     

    printWelcomeMessage();

    
    do {
        cout << "\n-----------------------------------------" << endl;
        cout << "Enter details for Employee Number " << (employeeCount + 1) << endl;
        cout << "-----------------------------------------" << endl;

        
        cout << "Enter Employee Name: ";
        cin.ignore(); 
        getline(cin, names[employeeCount]);

        
        printMenu();
        cin >> sectors[employeeCount];

        
        while (sectors[employeeCount] != 1 && sectors[employeeCount] != 2) {
            cout << "Invalid Choice! Please enter 1 or 2 again: ";
            cin >> sectors[employeeCount];
        }

    
        cout << "Enter Monthly Salary: ";
        cin >> salaries[employeeCount];

        
        if (sectors[employeeCount] == 1) {
            
            taxes[employeeCount] = checkGovTax(salaries[employeeCount]);
        } 
        else {
            
            taxes[employeeCount] = checkPrivateTax(salaries[employeeCount]);
        }

        cout << ">> Tax Calculated and Saved Successfully! <<" << endl;

        employeeCount++; 

        
        cout << "\nDo you want to add another employee record? (y/n): ";
        cin >> repeatChoice;

    } while (repeatChoice == 'y' || repeatChoice == 'Y');


    cout << "\n\n==========================================================" << endl;
    cout << "                FINAL TAX SUMMARY REPORT                  " << endl;
    cout << "==========================================================" << endl;
    cout << "Sr#\tName\t\tSector\t\tSalary\t\tTax" << endl;
    cout << "----------------------------------------------------------" << endl;

    float totalTaxCollected = 0;

    
    for (int i = 0; i < employeeCount; i++) {
        cout << (i + 1) << "\t" << names[i] << "\t\t";
        
        if (sectors[i] == 1) {
            cout << "Govt\t\t";
        } else {
            cout << "Private\t\t";
        }

        cout << salaries[i] << "\t\t" << taxes[i] << endl;
        
    
        totalTaxCollected = totalTaxCollected + taxes[i];
    }

    cout << "----------------------------------------------------------" << endl;
    cout << "Total Employees Processed : " << employeeCount << endl;
    cout << "Total Tax Revenue System  : " << totalTaxCollected << " PKR" << endl;
    cout << "==========================================================" << endl;

    return 0;
}


void printWelcomeMessage() {
    cout << "==========================================" << endl;
    cout << "     UNIVERSITY TAX MANAGEMENT PROJECT     " << endl;
    cout << "==========================================" << endl;
}

void printMenu() {
    cout << "Select Employment Sector: " << endl;
    cout << "  1. Government Employee" << endl;
    cout << "  2. Private Employee" << endl;
    cout << "Enter choice (1 or 2): ";
}
float checkGovTax(float salary) {
    float finalTax;
    
    if (salary <= 50000) {
        finalTax = salary * 0.05;
    } 
    else if (salary <= 100000) {
        finalTax = salary * 0.10;
    } 
    else {
        finalTax = salary * 0.15;
    }
    
    return finalTax; 
}

float checkPrivateTax(float salary) {
    float finalTax;
    
    if (salary <= 50000) {
        finalTax = salary * 0.08;
    } 
    else if (salary <= 1000000) {
        finalTax = salary * 0.12;
    } 
    else {
        finalTax = salary * 0.18;
    }
    
    return finalTax; 
}
