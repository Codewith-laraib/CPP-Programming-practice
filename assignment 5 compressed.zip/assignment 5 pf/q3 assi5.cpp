#include <iostream>
using namespace std;

struct StudentRecord {
    int roll_no;
    float marks[5];
};

int main() {
    StudentRecord s;
    float sum = 0.0;

    cout << "Enter roll number: ";
    cin >> s.roll_no;

    cout << "Enter marks for 5 subjects:\n";
    for(int i = 0; i < 5; i++) {
        cout << "Subject " << i + 1 << ": ";
        cin >> s.marks[i];
        sum += s.marks[i]; 
    }

    float average = sum / 5.0;

    cout << "\n--- Student Details ---\n";
    cout << "Roll Number: " << s.roll_no << endl;
    cout << "Marks obtained: ";
    for(int i = 0; i < 5; i++) {
        cout << s.marks[i] << " ";
    }
    cout << "\nAverage Marks: " << average << endl;

    return 0;
}
