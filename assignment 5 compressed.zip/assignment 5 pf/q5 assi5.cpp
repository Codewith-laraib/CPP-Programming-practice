#include <iostream>
#include <string>
using namespace std;

struct Employee {
    int emp_id;
    string name;
    float salary;
};

int main() {
    Employee emp[3];
    int max_idx = 0;

    
    for(int i = 0; i < 3; i++) {
        cout << "Enter details for Employee " << i + 1 << ":\n";
        cout << "Employee ID: ";
        cin >> emp[i].emp_id;
        cout << "Name: ";
        cin.ignore();
        getline(cin, emp[i].name);
        cout << "Salary: ";
        cin >> emp[i].salary;
        cout << endl;
    }

    
    for(int i = 1; i < 3; i++) {
        if(emp[i].salary > emp[max_idx].salary) {
            max_idx = i;
        }
    }

    cout << "--- Employee with the Highest Salary ---\n";
    cout << "Employee ID: " << emp[max_idx].emp_id << endl;
    cout << "Name: " << emp[max_idx].name << endl;
    cout << "Salary: " << emp[max_idx].salary << endl;

    return 0;
}
