#include <iostream>
#include <string>
using namespace std;

struct Book {
    string title;
    string author;
    float price;
};

int main() {
    Book b[3];
    int max_idx = 0, min_idx = 0;

    
    for(int i = 0; i < 3; i++) {
        cout << "Enter details for Book " << i + 1 << ":\n";
        cout << "Title: ";
        if(i == 0) cin.ignore(); 
        getline(cin, b[i].title);
        cout << "Author: ";
        getline(cin, b[i].author);
        cout << "Price: ";
        cin >> b[i].price;
        cin.ignore(); 
        cout << endl;
    }

    
    for(int i = 1; i < 3; i++) {
        if(b[i].price > b[max_idx].price) {
            max_idx = i;
        }
        if(b[i].price < b[min_idx].price) {
            min_idx = i;
        }
    }

    
    cout << "--- Most Expensive Book ---\n";
    cout << "Title: " << b[max_idx].title << "\nAuthor: " << b[max_idx].author << "\nPrice: " << b[max_idx].price << "\n\n";

    cout << "--- Lowest Priced Book ---\n";
    cout << "Title: " << b[min_idx].title << "\nAuthor: " << b[min_idx].author << "\nPrice: " << b[min_idx].price << endl;

    return 0;
}
