#include <iostream>
using namespace std;

int main() {
    int num1, num2, sum;
    int *ptr1, *ptr2;

    ptr1 = &num1;
    ptr2 = &num2;

    cout << "Enter two numbers: ";
    cin >> *ptr1 >> *ptr2; 

   
    sum = *ptr1 + *ptr2;

    cout << "Sum of " << *ptr1 << " and " << *ptr2 << " = " << sum << endl;

    return 0;
}
